import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { ModalSettingPage } from '../modal-setting/modal-setting';
import { JobsPage } from '../jobs/jobs';
import { GroupsPage } from '../groups/groups';
import { SchoolPage } from '../school/school';
import { EventPage } from '../event/event';
import { PaymentPage } from '../payment/payment';

/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {

  constructor(public navCtrl: NavController, public navParams: NavParams,public modalCtrl: ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProfilePage');
  }

  setting(){
    let profileModal = this.modalCtrl.create(ModalSettingPage);
    profileModal.present();
  }

  setJob(){
    this.navCtrl.push(JobsPage);
  }

  setGroup(){
    this.navCtrl.push(GroupsPage);
  }

  setSchool(){
    this.navCtrl.push(SchoolPage);
  }

  setEvent(){
    this.navCtrl.push(EventPage);
  }

  setPayment(){
    this.navCtrl.push(PaymentPage);
  }
  
}
