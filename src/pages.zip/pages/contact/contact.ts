import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ChatPage } from '../chat/chat';
import { ProfilePage } from '../profile/profile';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  constructor(public navCtrl: NavController) {

  }

  openChat(){
    this.navCtrl.push(ChatPage);
  }


  
  goToMes(){
    this.navCtrl.push(ContactPage);
  }

  goProfile(){
    this.navCtrl.push(ProfilePage);
  }

}
